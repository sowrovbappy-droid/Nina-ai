const test = require("node:test");
const assert = require("node:assert/strict");

test("project metadata defines expected start command", () => {
  const pkg = require("../package.json");
  assert.equal(pkg.scripts.start, "node src/server.js");
  assert.ok(pkg.dependencies.express);
  assert.ok(pkg.dependencies["sql.js"]);
});

test("environment example does not contain a real API key", () => {
  const fs = require("node:fs");
  const env = fs.readFileSync(require("node:path").join(__dirname, "..", ".env.example"), "utf8");
  assert.match(env, /AI_API_KEY=/);
  assert.match(env, /SESSION_SECRET=/);
  assert.doesNotMatch(env, /sk-[A-Za-z0-9]{20,}/);
});
