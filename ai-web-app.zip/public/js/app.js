const $ = (s) => document.querySelector(s);
const state = { user: null, conversationId: null, conversations: [], authMode: "login", busy: false };
const welcome = $("#welcome"), chat = $("#chat"), input = $("#messageInput"), sendBtn = $("#sendBtn"), notice = $("#notice");

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: "same-origin",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
}
function showNotice(message) {
  notice.textContent = message;
  notice.classList.remove("hidden");
}
function clearNotice() { notice.textContent = ""; notice.classList.add("hidden"); }
function setBusy(value) {
  state.busy = value;
  sendBtn.disabled = value;
  sendBtn.textContent = value ? "…" : "↑";
}
function setView(hasMessages) {
  welcome.classList.toggle("hidden", hasMessages);
  chat.classList.toggle("hidden", !hasMessages);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
// Minimal safe Markdown renderer: escapes HTML before adding a small supported Markdown subset.
function renderMarkdown(text) {
  let s = escapeHtml(text);
  s = s.replace(/```([\s\S]*?)```/g, (_m, code) => `<pre><code>${code.trim()}</code></pre>`);
  s = s.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  s = s.replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/\*([^*\n]+)\*/g, "<em>$1</em>");
  return s.split(/\n{2,}/).map(part => part.startsWith("<pre>") ? part : `<p>${part.replace(/\n/g, "<br>")}</p>`).join("");
}
function addMessage(role, content) {
  const article = document.createElement("article");
  article.className = `message ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "Y" : "✦";
  const body = document.createElement("div");
  body.className = "message-content-wrap";
  const label = document.createElement("div");
  label.className = "message-label";
  label.textContent = role === "user" ? "You" : "Nova AI";
  const text = document.createElement("div");
  text.className = "message-content";
  if (role === "assistant") text.innerHTML = renderMarkdown(content);
  else text.textContent = content;
  body.append(label, text);
  article.append(avatar, body);
  chat.append(article);
  chat.scrollTop = chat.scrollHeight;
  return text;
}
function resetChat() {
  state.conversationId = null;
  chat.replaceChildren();
  setView(false);
  clearNotice();
  input.focus();
}
async function loadConversations() {
  if (!state.user) {
    $("#conversationList").innerHTML = '<p class="muted small">Sign in to save chats.</p>';
    return;
  }
  const data = await api("/api/conversations");
  state.conversations = data.conversations;
  renderConversations();
}
function renderConversations() {
  const list = $("#conversationList");
  list.replaceChildren();
  if (!state.conversations.length) {
    const p = document.createElement("p"); p.className = "muted small"; p.textContent = "Your chats will appear here."; list.append(p); return;
  }
  state.conversations.forEach(c => {
    const btn = document.createElement("button");
    btn.className = "conversation-item" + (c.id === state.conversationId ? " active" : "");
    btn.innerHTML = `<span aria-hidden="true">◷</span><span></span>`;
    btn.lastElementChild.textContent = c.title;
    btn.title = "Open conversation";
    btn.addEventListener("click", () => openConversation(c.id));
    btn.addEventListener("contextmenu", async e => {
      e.preventDefault();
      const title = prompt("Rename this conversation:", c.title);
      if (title === null) return;
      try { await api(`/api/conversations/${c.id}`, { method: "PATCH", body: JSON.stringify({ title }) }); await loadConversations(); }
      catch (err) { showNotice(err.message); }
    });
    list.append(btn);
  });
}
async function openConversation(id) {
  try {
    const data = await api(`/api/conversations/${id}`);
    state.conversationId = id;
    chat.replaceChildren();
    data.messages.forEach(m => addMessage(m.role, m.content));
    setView(data.messages.length > 0);
    if (!data.messages.length) setView(false);
    renderConversations();
    $("#sidebar").classList.remove("open");
    clearNotice();
  } catch (err) { showNotice(err.message); }
}
async function ensureConversation(firstMessage) {
  if (state.conversationId) return state.conversationId;
  if (!state.user) {
    $("#authDialog").showModal();
    throw new Error("Sign in or create an account to start a saved conversation.");
  }
  const title = firstMessage.slice(0, 42) || "New chat";
  const data = await api("/api/conversations", { method: "POST", body: JSON.stringify({ title }) });
  state.conversationId = data.conversation.id;
  await loadConversations();
  return state.conversationId;
}
async function sendMessage(value) {
  const content = String(value || "").trim();
  if (!content || state.busy) return;
  clearNotice();
  if (!state.user) {
    $("#authDialog").showModal();
    showNotice("Sign in to send a message and save your history.");
    return;
  }
  input.value = "";
  input.style.height = "auto";
  setView(true);
  addMessage("user", content);
  setBusy(true);
  let placeholder;
  try {
    const id = await ensureConversation(content);
    placeholder = addMessage("assistant", "Thinking…");
    const data = await api(`/api/conversations/${id}/messages`, { method: "POST", body: JSON.stringify({ content }) });
    placeholder.innerHTML = renderMarkdown(data.message.content);
    await loadConversations();
  } catch (err) {
    if (placeholder) placeholder.textContent = "Response unavailable.";
    showNotice(err.message);
  } finally {
    setBusy(false);
    chat.scrollTop = chat.scrollHeight;
    input.focus();
  }
}
function setAuthMode(mode) {
  state.authMode = mode;
  const register = mode === "register";
  $("#registerMode").classList.toggle("active", register);
  $("#loginMode").classList.toggle("active", !register);
  $("#nameLabel").classList.toggle("hidden", !register);
  $("#authName").required = register;
  $("#authPassword").autocomplete = register ? "new-password" : "current-password";
  $("#authSubmit").textContent = register ? "Create account" : "Sign in";
  $("#authError").textContent = "";
}
function updateUserUI() {
  $("#userBadge").textContent = state.user ? state.user.name : "Guest";
  $("#authBtn").textContent = state.user ? "Account" : "Sign in";
  $("#adminBtn").classList.toggle("hidden", !state.user || state.user.role !== "admin");
  $("#logoutBtn").classList.toggle("hidden", !state.user);
  $("#accountDetails").textContent = state.user ? `${state.user.name} · ${state.user.email} · ${state.user.role}` : "You are using Nova AI as a guest.";
}
async function init() {
  try {
    const data = await api("/api/auth/me");
    state.user = data.user;
  } catch (_) { state.user = null; }
  updateUserUI();
  await loadConversations().catch(err => showNotice(err.message));
}
$("#composer").addEventListener("submit", e => { e.preventDefault(); sendMessage(input.value); });
input.addEventListener("input", () => { input.style.height = "auto"; input.style.height = `${Math.min(input.scrollHeight, 180)}px`; });
input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("#composer").requestSubmit(); } });
$("#newChatBtn").addEventListener("click", resetChat);
document.querySelectorAll(".suggestion").forEach(btn => btn.addEventListener("click", () => { input.value = btn.dataset.prompt; input.focus(); input.style.height = "auto"; input.style.height = `${input.scrollHeight}px`; }));
$("#authBtn").addEventListener("click", () => state.user ? $("#accountDialog").showModal() : $("#authDialog").showModal());
$("#accountBtn").addEventListener("click", () => $("#accountDialog").showModal());
$("#loginMode").addEventListener("click", () => setAuthMode("login"));
$("#registerMode").addEventListener("click", () => setAuthMode("register"));
$("#authForm").addEventListener("submit", async e => {
  e.preventDefault();
  $("#authError").textContent = "";
  const register = state.authMode === "register";
  const payload = { email: $("#authEmail").value, password: $("#authPassword").value };
  if (register) payload.name = $("#authName").value;
  try {
    const data = await api(register ? "/api/auth/register" : "/api/auth/login", { method: "POST", body: JSON.stringify(payload) });
    state.user = data.user;
    $("#authDialog").close();
    $("#authForm").reset();
    updateUserUI();
    await loadConversations();
    clearNotice();
  } catch (err) { $("#authError").textContent = err.message; }
});
$("#logoutBtn").addEventListener("click", async () => {
  try { await api("/api/auth/logout", { method: "POST", body: "{}" }); }
  catch (err) { showNotice(err.message); }
  state.user = null; resetChat(); updateUserUI(); await loadConversations(); $("#accountDialog").close();
});
document.querySelectorAll("[data-close]").forEach(btn => btn.addEventListener("click", () => $(`#${btn.dataset.close}`).close()));
$("#themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
  try { localStorage.setItem("nova-theme", document.body.classList.contains("light") ? "light" : "dark"); } catch (_) {}
});
try { if (localStorage.getItem("nova-theme") === "light") document.body.classList.add("light"); } catch (_) {}
$("#menuBtn").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
$("#adminBtn").addEventListener("click", async () => {
  try {
    const d = await api("/api/admin/stats");
    $("#adminStats").innerHTML = [["Users", d.users], ["Conversations", d.conversations], ["Messages", d.messages], ["AI configured", d.aiConfigured ? "Yes" : "No"]].map(([label, value]) => `<div class="stat"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
    $("#adminDialog").showModal();
  } catch (err) { showNotice(err.message); }
});
init();
