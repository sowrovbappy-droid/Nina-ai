require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const helmet = require("helmet");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const rateLimit = require("express-rate-limit");
const initSqlJs = require("sql.js");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "..", "data");
const DB_FILE = path.join(DATA_DIR, "app.sqlite");
fs.mkdirSync(DATA_DIR, { recursive: true });

let db;
function persistDb() {
  const bytes = db.export();
  fs.writeFileSync(DB_FILE, Buffer.from(bytes));
}
function run(sql, params = []) {
  db.run(sql, params);
  persistDb();
}
function one(sql, params = []) {
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    return stmt.step() ? stmt.getAsObject() : null;
  } finally { stmt.free(); }
}
function many(sql, params = []) {
  const stmt = db.prepare(sql);
  const rows = [];
  try {
    stmt.bind(params);
    while (stmt.step()) rows.push(stmt.getAsObject());
  } finally { stmt.free(); }
  return rows;
}
function safeUser(user) {
  return user ? { id: user.id, name: user.name, email: user.email, role: user.role, created_at: user.created_at } : null;
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in first." });
  req.user = one("SELECT id, name, email, role, created_at FROM users WHERE id = ?", [req.session.userId]);
  if (!req.user) return req.session.destroy(() => res.status(401).json({ error: "Session expired. Sign in again." }));
  next();
}
function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false });
const aiLimiter = rateLimit({ windowMs: 60 * 1000, limit: 12, standardHeaders: "draft-7", legacyHeaders: false });

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "32kb" }));
app.use(session({
  name: "aiweb.sid",
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret-before-deploying",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "AI Web App", aiConfigured: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL) }));

app.post("/api/auth/register", authLimiter, async (req, res) => {
  const name = String(req.body.name || "").trim().slice(0, 60);
  const email = String(req.body.email || "").trim().toLowerCase().slice(0, 254);
  const password = String(req.body.password || "");
  if (name.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10 || password.length > 128) {
    return res.status(400).json({ error: "Enter a valid name/email and a password of 10–128 characters." });
  }
  if (one("SELECT id FROM users WHERE email = ?", [email])) return res.status(409).json({ error: "An account with this email already exists." });
  const hash = await bcrypt.hash(password, 12);
  const role = process.env.ADMIN_EMAIL && email === process.env.ADMIN_EMAIL.trim().toLowerCase() ? "admin" : "user";
  run("INSERT INTO users (name,email,password_hash,role,created_at) VALUES (?,?,?,?,?)", [name, email, hash, role, new Date().toISOString()]);
  const user = one("SELECT id,name,email,role,created_at FROM users WHERE email = ?", [email]);
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start a session." });
    req.session.userId = user.id;
    req.session.save(saveErr => saveErr ? res.status(500).json({ error: "Could not save session." }) : res.status(201).json({ user: safeUser(user) }));
  });
});

app.post("/api/auth/login", authLimiter, async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = one("SELECT * FROM users WHERE email = ?", [email]);
  if (!user || !(await bcrypt.compare(password, user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start a session." });
    req.session.userId = user.id;
    req.session.save(saveErr => saveErr ? res.status(500).json({ error: "Could not save session." }) : res.json({ user: safeUser(user) }));
  });
});
app.post("/api/auth/logout", (req, res) => req.session.destroy(err => {
  res.clearCookie("aiweb.sid");
  if (err) return res.status(500).json({ error: "Could not log out." });
  res.json({ ok: true });
}));
app.get("/api/auth/me", requireAuth, (req, res) => res.json({ user: safeUser(req.user) }));

app.get("/api/conversations", requireAuth, (req, res) => {
  res.json({ conversations: many("SELECT id,title,created_at,updated_at FROM conversations WHERE user_id=? ORDER BY updated_at DESC", [req.user.id]) });
});
app.post("/api/conversations", requireAuth, (req, res) => {
  const title = String(req.body.title || "New chat").trim().slice(0, 100) || "New chat";
  const now = new Date().toISOString();
  run("INSERT INTO conversations (user_id,title,created_at,updated_at) VALUES (?,?,?,?)", [req.user.id, title, now, now]);
  res.status(201).json({ conversation: one("SELECT id,title,created_at,updated_at FROM conversations WHERE id=last_insert_rowid()") });
});
app.get("/api/conversations/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const conversation = one("SELECT id,title,created_at,updated_at FROM conversations WHERE id=? AND user_id=?", [id, req.user.id]);
  if (!conversation) return res.status(404).json({ error: "Conversation not found." });
  res.json({ conversation, messages: many("SELECT id,role,content,created_at FROM messages WHERE conversation_id=? ORDER BY id", [id]) });
});
app.patch("/api/conversations/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  const title = String(req.body.title || "").trim().slice(0, 100);
  if (!title) return res.status(400).json({ error: "Title is required." });
  if (!one("SELECT id FROM conversations WHERE id=? AND user_id=?", [id, req.user.id])) return res.status(404).json({ error: "Conversation not found." });
  run("UPDATE conversations SET title=?,updated_at=? WHERE id=? AND user_id=?", [title, new Date().toISOString(), id, req.user.id]);
  res.json({ ok: true });
});
app.delete("/api/conversations/:id", requireAuth, (req, res) => {
  const id = Number(req.params.id);
  if (!one("SELECT id FROM conversations WHERE id=? AND user_id=?", [id, req.user.id])) return res.status(404).json({ error: "Conversation not found." });
  run("DELETE FROM messages WHERE conversation_id=?", [id]);
  run("DELETE FROM conversations WHERE id=? AND user_id=?", [id, req.user.id]);
  res.json({ ok: true });
});

app.post("/api/conversations/:id/messages", requireAuth, aiLimiter, async (req, res) => {
  const id = Number(req.params.id);
  const content = String(req.body.content || "").trim();
  if (!content || content.length > 8000) return res.status(400).json({ error: "Message must contain 1–8000 characters." });
  const conversation = one("SELECT id,title FROM conversations WHERE id=? AND user_id=?", [id, req.user.id]);
  if (!conversation) return res.status(404).json({ error: "Conversation not found." });
  if (!process.env.AI_API_KEY || !process.env.AI_MODEL) return res.status(503).json({ error: "AI is not configured yet. Add AI_API_KEY and AI_MODEL to .env, then restart the server." });

  const now = new Date().toISOString();
  run("INSERT INTO messages (conversation_id,role,content,created_at) VALUES (?,?,?,?)", [id, "user", content, now]);
  const history = many("SELECT role,content FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 16", [id]).reverse();
  const apiUrl = process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions";
  try {
    const response = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": `Bearer ${process.env.AI_API_KEY}` },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [{ role: "system", content: process.env.AI_SYSTEM_PROMPT || "You are a helpful assistant." }, ...history],
        temperature: 0.7
      }),
      signal: AbortSignal.timeout(60000)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      console.error("AI provider returned HTTP", response.status);
      return res.status(502).json({ error: "The AI provider could not complete the request. Check the provider settings and quota." });
    }
    const answer = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
    if (typeof answer !== "string" || !answer.trim()) return res.status(502).json({ error: "The AI provider returned an empty or unsupported response." });
    const created = new Date().toISOString();
    run("INSERT INTO messages (conversation_id,role,content,created_at) VALUES (?,?,?,?)", [id, "assistant", answer, created]);
    run("UPDATE conversations SET updated_at=?, title=CASE WHEN title='New chat' THEN ? ELSE title END WHERE id=?", [created, content.slice(0, 42), id]);
    res.json({ message: { role: "assistant", content: answer, created_at: created } });
  } catch (err) {
    console.error("AI request failed:", err.name || "Error");
    res.status(502).json({ error: "Could not reach the AI provider. Check the connection and try again." });
  }
});

app.get("/api/settings", requireAuth, (_req, res) => res.json({ theme: "system", aiConfigured: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL) }));
app.get("/api/admin/stats", requireAuth, requireAdmin, (_req, res) => {
  res.json({
    users: one("SELECT COUNT(*) AS count FROM users").count,
    conversations: one("SELECT COUNT(*) AS count FROM conversations").count,
    messages: one("SELECT COUNT(*) AS count FROM messages").count,
    aiConfigured: Boolean(process.env.AI_API_KEY && process.env.AI_MODEL)
  });
});

app.use(express.static(path.join(__dirname, "..", "public")));
app.use((err, _req, res, _next) => {
  console.error("Request error:", err.message);
  res.status(500).json({ error: "An unexpected server error occurred." });
});

(async () => {
  const SQL = await initSqlJs();
  db = fs.existsSync(DB_FILE) ? new SQL.Database(new Uint8Array(fs.readFileSync(DB_FILE))) : new SQL.Database();
  db.run(`PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL,
      created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT, conversation_id INTEGER NOT NULL, role TEXT NOT NULL,
      content TEXT NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
    );
    CREATE INDEX IF NOT EXISTS idx_conversations_user_updated ON conversations(user_id, updated_at);
    CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id, id);`);
  persistDb();
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI Web App running at http://127.0.0.1:${PORT}`);
    console.log(`AI configured: ${Boolean(process.env.AI_API_KEY && process.env.AI_MODEL)}`);
  });
})();
